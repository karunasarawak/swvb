<?php

namespace App\Http\Controllers;

use App\CreditNoteTypes;
use Illuminate\Http\Request;

class CreditNoteTypesController extends Controller
{
}
