<?php return array (
  'add-attendee-form' => 'App\\Http\\Livewire\\AddAttendeeForm',
  'tours-attendee' => 'App\\Http\\Livewire\\ToursAttendee',
);