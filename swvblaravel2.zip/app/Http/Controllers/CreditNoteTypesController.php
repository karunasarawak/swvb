<?php

namespace App\Http\Controllers;

use App\CreditNoteType;
use Illuminate\Http\Request;

class CreditNoteTypesController extends Controller
{
}
