function clearInvoiceDetail()
{
    var selectItem = document.getElementById('item');
    selectItem.selectedIndex = 0;

    var txtAmount = document.getElementById('amount');
    txtAmount.value = "";

    var txtItemName = document.getElementById('item_name');
    txtItemName.value = "";
}